public class abc {
/*

    long tEnd = System.currentTimeMillis();
    long tDelta = tEnd -  detection.tStart;
    double elapsedSeconds = tDelta / 1000.0;

*/


/*
                                            long tEnd = System.currentTimeMillis();
                                            long tDelta = tEnd -  detection.tStart;
                                            double elapsedSeconds = tDelta / 1000.0;

                                            if (elapsedSeconds < 5)
                                            {
                                                continue;
                                            }else
                                                {
                                                    detection.tStart=System.currentTimeMillis();
                                                    Log.i("ABC", "$$$$$$  NO MATCH  ==Resetted"  );
                                                }
                                            headerTextView.setText("NO MATCH");
                                            footerTextView.setText("NO MATCH");

                                            hideFooter();
*/
    //  Log.i("ABC", "$$$$$$  NO MATCH  =="+detection.tStart );




                                       /* for (Text element : line.getComponents()) {
                                            //extract scanned text words here
                                            Log.i("ABCD-lines", "$$$$$$  Element=" +   element.getValue());
                                            }*/

}

/*

   private boolean processContainer(String elementValue)
 {
//        Log.i("ABC-processContainer", "Processing the Element  "+ elementValue);
//
//        if ( containerListOf.containsKey(elementValue) ) {
//            List<String> val = new ArrayList<String>();
//            val = (List<String>)containerListOf.get(elementValue);
//
//            footerTextView.setText(  "Shipping Line: " +  val.get(1) +  " \n SB NO:" + val.get(0)+ "\n DATE:" + val.get(3));
//            // footerTextView.setVisibility(View.VISIBLE);
//            Log.i("ABC-processContainer", "VISIBLE");
//            if(val.get(4).equals("Red")){
//                footerTextView.setBackgroundColor(Color.parseColor("#99FF0000"));
//                Log.i("ABC-processContainer", "FOUND Red");
//            }
//            else if(val.get(4).equals("Blue")){
//                footerTextView.setBackgroundColor(Color.parseColor("#9942E2F4"));
//                Log.i("ABC-processContainer", "FOUND Orange");
//            }else if (val.get(4).equals("Green")){
//                footerTextView.setBackgroundColor(Color.parseColor("#9900FF00"));
//                Log.i("ABC-processContainer", "FOUND Green");
//            }
//            headerTextView.setText(elementValue);
//            Log.i("ABC-processContainer", "BOMBAY FOUND " + " WITH LEVEL=" + val.get(4));
//            return true;
//        }
//        else{
//            //footerTextView.setVisibility(View.INVISIBLE);
//            Log.i("ABC-processContainer", "INVISIBLE");
//            Log.i("ABC-processContainer", "bombay2 NOT FOUND ");
//            footerTextView.setBackgroundColor(Color.parseColor("#00DDD9D9"));
//            return false;
//        }
     return false;

    }

    private boolean processElement(String elementValue)
    {   Log.w("ABC", "Processing the Element  "+ elementValue);

        if ( containerListOf.containsKey(elementValue) ) {
            List<String> val = new ArrayList<String>();
            val = (List<String>)containerListOf.get(elementValue);

            footerTextView.setText(   val.get(0) +  " , " + val.get(3)+ " ,\n" + val.get(4));
           // footerTextView.setVisibility(View.VISIBLE);
            Log.w("ABC", "VISIBLE");
            if(val.get(5).equals("LEVEL1")){
                footerTextView.setBackgroundColor(Color.parseColor("#9936F948"));
                Log.w("ABC", "FOUND GOA");
            }
            else if(val.get(5).equals("LEVEL2")){
                footerTextView.setBackgroundColor(Color.parseColor("#99F0A436"));
                Log.w("ABC", "FOUND MAHARASHTRA");
            }else if (val.get(5).equals("LEVEL3")){
                footerTextView.setBackgroundColor(Color.parseColor("#99F0364A"));
                Log.w("ABC", "FOUND GUJRAT");
            }
            headerTextView.setText(elementValue);
            Log.w("ABC", "BOMBAY FOUND " + " WITH LEVEL=" + val.get(5));
           return true;
        }
        else{
            //footerTextView.setVisibility(View.INVISIBLE);
            Log.w("ABC", "INVISIBLE");
            Log.w("ABC", "bombay2 NOT FOUND ");
            footerTextView.setBackgroundColor(Color.parseColor("#00DDD9D9"));
            return false;
        }
    }

    private void readData() {
        InputStream is = getResources().openRawResource(R.raw.pincodelist);
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8")));
        String line = "";


        try {
            int loopCounter  =0;
            while ((line = reader.readLine()) != null) {


                loopCounter++;

                if (loopCounter > 0) {
                    // Split the line into different tokens (using the comma as a separator).
                    String[] tokens = line.split(",");

                    List<String> list = new ArrayList<String>();

                    list.add(tokens[0]);
                    list.add(tokens[1]);
                    list.add(tokens[2]);
                    list.add(tokens[3]);
                    list.add(tokens[4]);
                 //   list.add(tokens[5]);

                    containerListOf.put(tokens[3],list);


                /*



                // Read the data and store it in the WellData POJO.
                WellData wellData = new WellData();
                wellData.setOwner(tokens[0]);
                wellData.setApi(tokens[1]);
                wellData.setLongitude(tokens[2]);
                wellData.setLatitude(tokens[3]);
                wellData.setProperty(tokens[4]);
                wellData.setWellName(tokens[5]);
                wellDataList.add(wellData);*/

/*                    Log.d("readData-Csv", "Just Created " + line);
                            Log.d("readData-Csv", "tokens[0]=>" + tokens[0] + "<=");
                            Log.d("readData-Csv", "tokens[1]=>" + tokens[1] + "<=");
                            Log.d("readData-Csv", "tokens[2]=>" + tokens[2] + "<=");
                            Log.d("readData-Csv", "tokens[3]=>" + tokens[3] + "<=");
//                    Log.d("readData-Csv", "tokens[4]=>" + tokens[4] + "<=");
                            //                  Log.d("readData-Csv", "tokens[5]=>" + tokens[5] + "<=");

                            }
                            }
                            Log.d("readData-Csv", "Done " );
                            } catch (IOException e1) {
                            Log.e("readData-Csv", "Error" , e1);
                            e1.printStackTrace();
                            }
                            }




    public Bitmap decodeFile(File f) {  //FUNCTION BY Arshad Parwez
        Bitmap b = null;
        try {
            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;

            FileInputStream fis = new FileInputStream(f);
            BitmapFactory.decodeStream(fis, null, o);
            fis.close();
            int IMAGE_MAX_SIZE = 1000;
            int scale = 1;
            if (o.outHeight > IMAGE_MAX_SIZE || o.outWidth > IMAGE_MAX_SIZE) {
                scale = (int) Math.pow(
                        2,
                        (int) Math.round(Math.log(IMAGE_MAX_SIZE
                                / (double) Math.max(o.outHeight, o.outWidth))
                                / Math.log(0.5)));
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            fis = new FileInputStream(f);
            b = BitmapFactory.decodeStream(fis, null, o2);
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return b;
    }

 */