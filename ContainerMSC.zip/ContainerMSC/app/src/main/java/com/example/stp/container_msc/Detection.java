package com.example.stp.container_msc;

public class Detection
{
    String detectedValue ;
    long tStart ;
    boolean isDetectionTriggered ;
    boolean  isDetectionSuccessful;
    boolean isLocked;
    boolean isApiContainerFound ;

}
