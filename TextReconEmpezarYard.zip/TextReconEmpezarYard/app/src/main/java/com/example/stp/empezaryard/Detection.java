package com.example.stp.empezaryard;

public class Detection
{
    String detectedValue ;
    long tStart ;
    boolean isDetectionTriggered ;
    boolean  isDetectionSuccessful;
    boolean isLocked;
    boolean isApiContainerFound ;

}
