package com.example.stp.empezaryard;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.graphics.Color;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.text.Text;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    SurfaceView cameraView;
    TextView textView;
    CameraSource cameraSource;
    final int RequestCameraPermissionID = 1001;
    LayoutInflater controlInflater = null;
    TextView errorTextView;
    TextView headerTextView ;
    Map<String,List<String>> containerListOf ;
    String URL;
    String detectedvalue ;
    Boolean isPincodeFound;
   // ProgressDialog pDialog;


    TextView txtYardLocation;
    TextView txtYard1;
    TextView txtYard2;

    RelativeLayout layoutMain;
    Detection detection;
    boolean IsApiCallInProgress ;
    private RelativeLayout CamView;
    public static Camera camera = null;
        private Bitmap inputBMP = null, bmp, bmp1;
    boolean isStartedTextRecognition = false;
    public static byte COUNTER_MAX  = 10;
    byte counter;
    boolean isPauseCounterForYardSend ;
    boolean isResponseSendYardSuccess;
    boolean isApiCallSendYardInProgress;

    ProgressDialog progressDialogForSendToYard;

    private String globalContainerCode;
    String returnValueFromSendToyardApi ;
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode) {

            case RequestCameraPermissionID:

            case 0: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                    try {
                        cameraSource.start(cameraView.getHolder());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }


        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // getSupportActionBar().setTitle("Pincode Recognizer");

        ProgressDialog pDialog;
        setContentView(R.layout.activity_main);
        containerListOf = new HashMap<String,List<String>>();
        cameraView = (SurfaceView) findViewById(R.id.surface_view);
        textView = (TextView) findViewById(R.id.textView1);
        errorTextView = (TextView) findViewById(R.id.errorText);
        headerTextView = (TextView) findViewById(R.id.headerTextView);

        txtYardLocation = (TextView) findViewById(R.id.txtLocation);
        txtYard1 = (TextView) findViewById(R.id.txtYard1);
        txtYard2 = (TextView) findViewById(R.id.txtYard2);

        layoutMain = (RelativeLayout) findViewById(R.id.fotterLayoutMain);
        CamView = (RelativeLayout) findViewById(R.id.camview);

        layoutMain.setBackgroundColor(Color.parseColor("#00000000"));
        txtYardLocation.setText("");
        txtYardLocation.setBackgroundColor(Color.parseColor("#00000000"));
        txtYard1.setBackgroundColor(Color.parseColor("#00000000"));
        txtYard2.setBackgroundColor(Color.parseColor("#00000000"));
        txtYard1.setTextColor(Color.parseColor("#00000000"));
        txtYard2.setTextColor(Color.parseColor("#00000000"));

        detection = new Detection();
        detection.tStart= 0;
        detection.isDetectionSuccessful = false;
        detection.isDetectionTriggered = false;
        detection.isLocked = false;
        IsApiCallInProgress = false;

        isPauseCounterForYardSend = false;

        headerTextView.setOnClickListener(new View.OnClickListener() {    //THE BUTTON CODE
            public void onClick(View v) {
            }
        });


        new Thread( new Runnable(){
            @Override
            public void run(){
                Looper.prepare();
                //do work here
                       counter = COUNTER_MAX ;
                        while (true){
                                 try {

                                   //  Log.i("ABC-Counter", "run: Infinite While counter="+counter   );
                                     if(isPauseCounterForYardSend){
                                 //        Log.i("ABC-Counter-CONTINUE", "run: EXIT INFINITE WHILE ");
                                         continue;}
                                     Thread.sleep(300);
                                     if(isPauseCounterForYardSend){
                                        // Log.i("ABC-Counter-CONTINUE", "run: EXIT INFINITE WHILE ");
                                         continue;
                                     }


                                     if (isStartedTextRecognition) {
                                         Log.i("ABC-Counter", "run: Infinite While TOMCRUISE "+isStartedTextRecognition + " " + detection.isDetectionTriggered + "-" + detection.isDetectionSuccessful   );
                                         if (detection.isDetectionTriggered && detection.isDetectionSuccessful) {
                                             Log.i("ABC-Counter", "run: Successful Detection ");
                                             counter = COUNTER_MAX;
                                             detection.isDetectionTriggered = false;
                                             detection.isLocked = false;
                                         } else

                                         {
                                             counter--;
                                             Log.i("ABC-Counter", "run: False/No/Detection Counter = " +  counter);
                                             if (counter == 0) {
                                                 //==================
                                                 runOnUiThread(new Runnable() {
                                                     @Override
                                                     public void run() {
                                                         hideFooter();
                                                         Log.i("ABC-Counter", "Hidding Footer Due to No Detection run: ");
                                                     }
                                                 });
                                                 //------------------
                                                 counter = COUNTER_MAX;
                                             }
/*
                                             if (headerTextView.getText().length() > 0) {
                                                 if (!detection.isApiContainerFound) {
                                                     runOnUiThread(new Runnable() {
                                                         @Override
                                                         public void run() {
                                                             footerTextView.setBackgroundColor(Color.parseColor("#99ab1212")); //SHOW NO MATCH
                                                             footerTextView.setText("RECORD NOT FOUND");
                                                             Log.i("ABCDE", "RECORD_NOT_FOUND " + headerTextView.getText());
                                                         }
                                                     });
                                                 }
                                             }*/
                                         }
                                     }


                                 } catch (InterruptedException e) {
                                    Log.i("ABC-Counter", "run: " + e.getMessage());
                                    e.printStackTrace();
                                }



                         }//While

            }
        }).start();




        TextRecognizer textRecognizer = new TextRecognizer.Builder(getApplicationContext()).build();
        if (!textRecognizer.isOperational()) {
            Log.w("ABC", "NO TEXT RECOGNISER");

           }
        else
        {
            cameraSource = new CameraSource.Builder(getApplicationContext(), textRecognizer)
                    .setFacing(CameraSource.CAMERA_FACING_BACK)
                    .setRequestedPreviewSize(1280, 1024)
                    .setRequestedFps(15.0f)
                    .setAutoFocusEnabled(true)
                    .build();

            cameraView.getHolder().addCallback(new SurfaceHolder.Callback() {
                @Override
                public void surfaceCreated(SurfaceHolder surfaceHolder) {
                    try {
                        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.

                            ActivityCompat.requestPermissions(
                                    MainActivity.this, new String[]{Manifest.permission.CAMERA}, 1001
                            );
                            return;
                        }
                        CameraSource start = cameraSource.start(cameraView.getHolder());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
                }

                @Override
                public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
                    cameraSource.stop();
                }
            });


            textRecognizer.setProcessor(new Detector.Processor<TextBlock>() {
                @Override
                public void release() {

                }

                @Override
                public void receiveDetections(final Detector.Detections<TextBlock> detections) {
                    final SparseArray<TextBlock> items = detections.getDetectedItems();
                    if (items.size() != 0) {
                        isStartedTextRecognition =   true ;
                        detection.isDetectionTriggered = true;

                        textView.post(new Runnable() {
                            @Override
                            public void run() {

                                Pattern mPattern  =  Pattern.compile("^[A-Z]{3}[JRUZ][0-9]{7}$");
                                StringBuilder stringBuilder = new StringBuilder();
                                isPincodeFound =  false ;
                                Log.i("ABCD", "==================================================================");
                                Log.i("ABCD", "$$$$$$ Detections Encountered with items.size = " + items.size());
                                for (int i = 0; i < items.size(); ++i) {
                                    if(IsApiCallInProgress )
                                    {
                                        Log.i("ABCD", "BREAK SINCE_API_CALL_IN_PROGRESS ");
                                        break;
                                    }
                                    if( isPauseCounterForYardSend)
                                    {
                                        Log.i("ABCD", "BREAK SINCE isPauseCounterForYardSend ");
                                        break;
                                    }
                                    TextBlock item = items.valueAt(i);
                                    Log.i("ABCD", "$$$$$$  The TextBlockValue at ("+ i + ")= ===>" + item.getValue()+ "<====");
                                    stringBuilder.append(item.getValue());
                                    stringBuilder.append("\n");


                                    for (Text line : item.getComponents()) {
                                        Log.i("ABCD-lines", "$$$$$$  Line=" +   line.getValue());
                                        String DetectedContainerNoWhiteSpace  = line.getValue().replaceAll(" ","");

                                        Matcher matcher  = mPattern.matcher(DetectedContainerNoWhiteSpace);
                                        detectedvalue = DetectedContainerNoWhiteSpace;

                                        if(matcher.find()){
                                            detection.detectedValue = ";" ;
                                            detection.tStart= System.currentTimeMillis();
                                            Log.i("ABCD-lines", "$$$$$$  bingo RegEx Match ,  Value=" +   detectedvalue);
                                            Log.i("ABCD-lines", "$$$$$$  bingo RegEx Match ,  tStart=" +   detection.tStart);
                                            headerTextView.setText(detectedvalue);
                                            Log.i("ABCDE", "Show_HEADER_REGEX " + detectedvalue );
                                            processContainerWithApiCall(detectedvalue);
                                            break;
                                        }
                                        else{
                                            if(!detection.isLocked)
                                            {  detection.isDetectionSuccessful  = false ;
                                                Log.i("ABC-Cass", " ==> OFF <==  NO_REG_MATCH");
                                            }
                                            else{
                                                Log.i("ABC-Cass", " ==> OFF <==  NO_REG_MATCH [XX LOCK XX]");
                                            }
                                        }
                                    }

                                }

                                if(isPincodeFound==false){
//                                   Log.w("ABC", "$$$$$$  NO PINCODE IN DETECTIONS");
//
                                   }
                            }
                        });
                    }
                }
            });
        }//textRecognizer.isOperational


    }//OnCreate

    private void hideFooter()
    {
        headerTextView.setText("");
        Log.i("ABCDE", "hideFooter: RESET_HEADER");

        errorTextView.setBackgroundColor(Color.parseColor("#00000000"));
        errorTextView.setText("");
        Log.i("ABCDE", "hideFooter: RESET_ERROR_BOX");

        hideDetailsBox("COUNTER");

        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat(":ss:SSS");
        String formattedDate = df.format(c.getTime());
        textView.setText("Hide " + formattedDate );
    }

    void hideDetailsBox(String reason ){
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat(":ss:SSS");
        String formattedDate = df.format(c.getTime());
        textView.setText("Hide " + formattedDate );

        layoutMain.setBackgroundColor(Color.parseColor("#00000000"));
        txtYardLocation.setText("");
        txtYardLocation.setBackgroundColor(Color.parseColor("#00000000"));
        txtYard1.setBackgroundColor(Color.parseColor("#00000000"));
        txtYard2.setBackgroundColor(Color.parseColor("#00000000"));
        txtYard1.setTextColor(Color.parseColor("#00000000"));
        txtYard2.setTextColor(Color.parseColor("#00000000"));
        Log.i("ABCDE-MILIBAND", "HIDING DETAILS BOX ("+reason+") "+formattedDate );
    }

    private boolean processContainerWithApiCall(final String containerCode)
    {
        IsApiCallInProgress =  true;
        globalContainerCode = containerCode;
        RequestQueue queue =  Volley.newRequestQueue(this);

        URL = "https://pin-code-recognizer.appspot.com/api/Yard/GetYardDetails/"  + containerCode;
        //ex :  https://pin-code-recognizer.appspot.com/api/Yard/GetYardDetails/HLXU8552543
//        pDialog = new ProgressDialog(MainActivity.this)   ;
//        pDialog.setMessage("Loading ....");
//        pDialog.show();
        Log.i("ABC", "processContainerWithApiCall:  Calling URL " + URL);

        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null,

                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // display response
                        Log.i("ABC-processContainer", "FOUND-IN-API_RESPONSE "+response.toString());
                        try{

                            String location  = response.getString("location");
                            String color1=  response.getString("color1");
                            String color2=  response.getString("color2");

                            txtYardLocation.setText(location);
                            txtYard1.setBackgroundColor(Color.parseColor(color1));
                            txtYard2.setBackgroundColor(Color.parseColor(color2));
                            txtYardLocation.setBackgroundColor(Color.parseColor("#99DDD9D9"));
                            txtYard1.setTextColor(Color.parseColor("#000000"));
                            txtYard2.setTextColor(Color.parseColor("#000000"));
                            detection.isDetectionSuccessful  = true ;
                            detection.isLocked = true ;

                            Calendar c = Calendar.getInstance();
                            SimpleDateFormat df = new SimpleDateFormat(":ss:SSS");
                            String formattedDate = df.format(c.getTime());
                            textView.setText("Display " + formattedDate );
                            Log.i("ABC-MILIBAND", "DISPLAY "+ formattedDate);
                            Log.i("ABC-processContainer", "FOUND-IN-API ");
                            headerTextView.setText(containerCode);
                            Log.i("ABCDE", "  SHOW_HEADER_API " + containerCode);
                            Log.i("ABC-Cass", " ==> ON  <==  API");
                            errorTextView.setBackgroundColor(Color.parseColor("#00000000"));
                            errorTextView.setText("");
                            Log.i("ABCDE", "HIDE_ERROR_API: HIDE_ERROR_BOX");
                            IsApiCallInProgress = false;
                            detection.isApiContainerFound = true;

                        }
                        catch (JSONException e){
                            IsApiCallInProgress =  false;
                            detection.isApiContainerFound = false;

                            errorTextView.setBackgroundColor(Color.parseColor("#99ab1212")); //SHOW NO MATCH
                            errorTextView.setText("RECORD NOT FOUND");
                            headerTextView.setText(containerCode);
                            Calendar c = Calendar.getInstance();
                            SimpleDateFormat df = new SimpleDateFormat(":ss:SSS");
                            String formattedDate = df.format(c.getTime());
                            textView.setText("Hide " + formattedDate );

                            counter = COUNTER_MAX;
                            hideDetailsBox("JSONException");

                            Log.i("ABCDE", "RECORD_NOT_FOUND 507" + headerTextView.getText());
                            Log.i("ABC-processContainer", "JSONException "+e.getMessage());
                            e.printStackTrace();

                        }
                        catch(Exception e){
                            IsApiCallInProgress =  false;
                            detection.isApiContainerFound = false;

                            errorTextView.setBackgroundColor(Color.parseColor("#99EFB031")); //SHOW NO MATCH
                            errorTextView.setText("RECORD NOT FOUND");
                            headerTextView.setText(containerCode);

                            Calendar c = Calendar.getInstance();
                            SimpleDateFormat df = new SimpleDateFormat(":ss:SSS");
                            String formattedDate = df.format(c.getTime());
                            textView.setText("Hide " + formattedDate );

                            counter = COUNTER_MAX;
                            hideDetailsBox("APIException");

                            Log.i("ABCDE", "RECORD_NOT_FOUND EXCEPTION 529 " + headerTextView.getText());
                            Log.i("ABC-processContainer", "Exception "+e.getMessage());
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       // pDialog.hide();
                        errorTextView.setBackgroundColor(Color.parseColor("#99ab1212")); //SHOW NO MATCH
                        errorTextView.setText("RECORD NOT FOUND");
                        headerTextView.setText(containerCode);

                        hideDetailsBox("error-> Counter="+ counter);
                        counter = COUNTER_MAX;
                        Log.i("ABCDE", "RECORD_NOT_FOUND 521 " + headerTextView.getText());

                        IsApiCallInProgress = false;
                        detection.isApiContainerFound = false;
                        Log.i("ABC-processContainer",  "VolleyError error:" +  error.toString());
                    }
                }
        );
        queue.add(objectRequest);
        Log.i("ABC-processContainer", "API FINISHED WITH SUCCESS");
        return true ;
    }


    public  void  sendContainerToYard(View view)
    {
        isPauseCounterForYardSend = true;
        final View finalView = view;



        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(MainActivity.this);
        builder.setCancelable(false);
      //  builder.setMessage("Send "+ globalContainerCode  + " to  Yard "+ view.getTag()  +  " ?");
        builder.setMessage(" Confirm Yard  Location  ?");

         builder.setPositiveButton("Send to " + view.getTag() , new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                isApiCallSendYardInProgress = true;
                processContainerSendToYardApi(globalContainerCode ,  (String)finalView.getTag());

                progressDialogForSendToYard = new ProgressDialog(MainActivity.this)   ;
                progressDialogForSendToYard.setMessage("Sending ....");
                progressDialogForSendToYard.show();
                new Thread( new Runnable(){
                    @Override
                    public void run(){
                        Looper.prepare();
                        //do work here
                        Log.i("ABC-ALERTDIALOG+ve", "run: ");
                        while (isApiCallSendYardInProgress){
                            try {
                                Thread.sleep(300);
                                if(isApiCallSendYardInProgress==false){
                                    Log.i("ABC-ALERTDIALOG-BREAK", "run: EXIT INFINITE WHILE ");
                                    if( isResponseSendYardSuccess  )
                                    {
                                        //==================
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Log.i("ABC-ALERTDIALOG", "onClick: Toasting SUCCESS");
                                                Toast.makeText(getApplicationContext(), returnValueFromSendToyardApi, Toast.LENGTH_LONG).show();
                                                progressDialogForSendToYard.hide();
                                            }
                                        });
                                        //------------------
                                    }else{
                                        //==================
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Log.i("ABC-ALERTDIALOG", "onClick: Toasting UN-SUCCESS");
                                                progressDialogForSendToYard.hide();
                                                Toast.makeText(getApplicationContext(), "Unsuccessful in Sending Action ", Toast.LENGTH_LONG).show();
                                            }
                                        });
                                        //------------------
                                    }
                                    break;
                                }
                                Log.i("ABC-ALERTDIALOG-BREAK", "run: Infinite While ### ALERT"  );

                            } catch (InterruptedException e) {
                                Log.i("ABC-ALERTDIALOG-BREAK", "run: " + e.getMessage());
                                e.printStackTrace();
                            }
                        }//While
                    }
                }).start();
            }
        });


        builder.setNegativeButton("No Action", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Log.i("ABC-ALERTDIALOG-ve", "run: ");
                dialogInterface.cancel();
                isPauseCounterForYardSend = false;
                Log.i("ABC-BREAK-MAKE-FALSE", "processContainerToYard: BREAK ");
            }
        });

        builder.show();

    }


    private boolean processContainerSendToYardApi(final String containerCode,final String yardCode)
    {

        RequestQueue queue =  Volley.newRequestQueue(this);
          isResponseSendYardSuccess = false;

        URL = "https://pin-code-recognizer.appspot.com/api/Yard/SendToYard/"  + containerCode+"/"+yardCode;
////////ex: FOR YARD 1B --> https://pin-code-recognizer.appspot.com/api/Yard/SendToYard/HLBU1151814/1B
        Log.i("ABC", "SendToYardApi:  Calling URL " + URL);

        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null,

                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // display response
                        Log.i("ABC-SendToYardApi", "processContainerSendToYardApi_RESPONSE "+response.toString());
                        try{

                             returnValueFromSendToyardApi  = response.getString("response");


                                Log.i("ABC", "onResponse: GOT SUCCESS=>" + returnValueFromSendToyardApi);

                            isResponseSendYardSuccess =  true;
                            isPauseCounterForYardSend = false;
                            isApiCallSendYardInProgress =false;
                        }
                        catch (JSONException e){

                            Log.i("ABC-SendToYard", "JSONException "+e.getMessage());
                            e.printStackTrace();

                            isPauseCounterForYardSend = false;
                            isApiCallSendYardInProgress =false;
                        }
                        catch(Exception e){

                            Log.i("ABC-SendToYard", "Exception "+e.getMessage());
                            e.printStackTrace();
                            isPauseCounterForYardSend = false;
                            isApiCallSendYardInProgress =false;
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        isPauseCounterForYardSend = false;
                        isApiCallSendYardInProgress =false;
                        Log.i("ABC-SendToYard",  "VolleyError error:" +  error.toString());
                    }
                }
        );

        objectRequest.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));



        queue.add(objectRequest);
        Log.i("ABC-SendToYard", "API FINISHED WITH SUCCESS");
        return     isResponseSendYardSuccess = false;
    }

}


